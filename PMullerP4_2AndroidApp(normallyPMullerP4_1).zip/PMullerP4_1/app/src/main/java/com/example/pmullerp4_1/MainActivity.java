package com.example.pmullerp4_1;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    private EditText searchInput;
    private Button searchBtn;
    private TextView statusText;
    private LinearLayout resultsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchInput = findViewById(R.id.searchInput);
        searchBtn = findViewById(R.id.searchBtn);
        statusText = findViewById(R.id.statusText);
        resultsContainer = findViewById(R.id.resultsContainer);

        searchBtn.setOnClickListener(v -> performSearch());
    }

    private void performSearch() {
        final String term = searchInput.getText().toString().trim();
        if (TextUtils.isEmpty(term)) {
            statusText.setText("Enter a name.");
            return;
        }

        resultsContainer.removeAllViews();
        statusText.setText("Loading…");

        new Thread(() -> {
            // Call your own web service (running in Codespaces) instead of the public Amiibo API directly.
            // TODO: Replace the placeholder base URL below with your actual Codespaces URL, e.g.:
            // "https://your-username-95702-p4-xxxxx-8080.app.github.dev/amiiboSearch"
            String baseUrl = "https://shiny-system-r44pw7jx9vwr36gj-8080.app.github.dev/api/search";

            String urlStr = baseUrl
                    + "?q=" + urlEncode(term)
                    // optional, but nice if you want to log device info in future
                    + "&device=" + urlEncode(android.os.Build.MODEL)
                    + "&os=" + urlEncode(android.os.Build.VERSION.RELEASE)
                    + "&format=json";
            String body = httpGet(urlStr);
            if (body == null) {
                runOnUiThread(() -> statusText.setText("Network error."));
                return;
            }
            String trimmed = body.trim();
            if (!trimmed.startsWith("{") && !trimmed.startsWith("[")) {
                final String snippet = trimmed.length() > 200 ? trimmed.substring(0, 200) + "…" : trimmed;
                Log.e(TAG, "Non-JSON response from server: " + snippet);
                runOnUiThread(() -> statusText.setText("Server returned non-JSON (check Codespaces port visibility and URL)."));
                return;
            }
            try {
                JSONObject root = new JSONObject(body);

                // Our web service returns a reduced JSON of the form:
                // { "query": "...", "thirdPartyStatus": 200, "count": N, "items": [ {name, gameSeries, image}, ... ] }
                JSONArray arr = root.optJSONArray("items");
                int total = root.optInt("count", (arr != null) ? arr.length() : 0);

                if (arr == null || arr.length() == 0) {
                    runOnUiThread(() -> {
                        statusText.setText("No results.");
                        resultsContainer.removeAllViews();
                    });
                    return;
                }

                int finalTotal = total;
                runOnUiThread(() -> {
                    statusText.setText("Results: " + finalTotal);
                    resultsContainer.removeAllViews();
                });

                int k = Math.min(10, arr.length());
                for (int i = 0; i < k; i++) {
                    JSONObject o = arr.getJSONObject(i);
                    final String name = o.optString("name");
                    final String gameSeries = o.optString("gameSeries");
                    final String imageUrl = o.optString("image");

                    // Download image on background thread first
                    final Bitmap bmp = downloadBitmap(imageUrl);

                    runOnUiThread(() -> {
                        // Build a horizontal "card": image + text column
                        LinearLayout card = new LinearLayout(this);
                        card.setOrientation(LinearLayout.HORIZONTAL);
                        int pad = dp(8);
                        card.setPadding(pad, pad, pad, pad);

                        ImageView img = new ImageView(this);
                        img.setAdjustViewBounds(true);
                        int d = dp(90);
                        img.setMaxWidth(d);
                        img.setMaxHeight(d);
                        img.setMinimumWidth(d);
                        img.setMinimumHeight(d);
                        if (bmp != null) {
                            img.setImageBitmap(bmp);
                        }

                        LinearLayout textCol = new LinearLayout(this);
                        textCol.setOrientation(LinearLayout.VERTICAL);

                        TextView t1 = new TextView(this);
                        t1.setText(name);

                        TextView t2 = new TextView(this);
                        t2.setText(gameSeries);

                        textCol.addView(t1);
                        textCol.addView(t2);

                        card.addView(img);
                        card.addView(textCol);

                        resultsContainer.addView(card);
                    });
                }
            } catch (Exception e) {
                Log.e(TAG, "Parse error", e);
                runOnUiThread(() -> statusText.setText("Parse error."));
            }
        }).start();
    }

    private static String httpGet(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(urlStr);
            conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setRequestMethod("GET");
            int code = conn.getResponseCode();
            InputStream in = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                return sb.toString();
            }
        } catch (Exception e) {
            Log.e(TAG, "GET failed: " + urlStr, e);
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static Bitmap downloadBitmap(String urlStr) {
        HttpURLConnection conn = null;
        try {
            URL u = new URL(urlStr);
            conn = (HttpURLConnection) u.openConnection();
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            try (InputStream in = new BufferedInputStream(conn.getInputStream())) {
                return BitmapFactory.decodeStream(in);
            }
        } catch (Exception e) {
            Log.w(TAG, "Image load failed: " + urlStr, e);
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String urlEncode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return Math.round(v * d);
    }
}